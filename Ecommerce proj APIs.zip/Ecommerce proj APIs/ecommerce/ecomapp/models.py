from django.db import models

# Create your models here.
class Category(models.Model):
    title       =   models.CharField(max_length=100)

    class Meta:
        verbose_name_plural =   'Categories'

    def __str__(self):
        return self.title

class Dish(models.Model):
    title           =   models.CharField(max_length=50)
    category        =   models.ForeignKey(Category,related_name='dishes',on_delete=models.CASCADE)
    price           =   models.IntegerField()
    imageURL        =   models.URLField(null=True)
    quantity        =   models.IntegerField()
    date_created    =   models.DateField(auto_now_add= True)



    class Meta:
        verbose_name_plural =   'Dishes'

    # class Meta:
    #     order_at    =   ['-date_created']

    def __str__(self):
        return self.title

class Beverage(models.Model):
    name        =   models.CharField(max_length=100)
    category    =   models.ForeignKey(Category,related_name='beverages',on_delete=models.CASCADE)
    price           =   models.IntegerField()
    imageURL        =   models.URLField(null=True)
    quantity        =   models.IntegerField()
    # quantity    =   models.IntegerField()
    date_created    =   models.DateField(auto_now_add= True)


    # class Meta:
    #     order_at    =   ['-date_created']

    def __str__(self):
        return self.name
    



    


