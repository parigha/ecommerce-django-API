from rest_framework import serializers
from .models import Category,Dish,Beverage

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            'id',
            'title',
        )
        model = Category



class DishSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            'id',
            'title',
            'category',
            'price',
            'imageURL',
            'quantity',
            'date_created'
        )
        model = Dish


class BeverageSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            'id',
            'name',
            'category',
            'price',
            'imageURL',
            'quantity',
            'date_created'
        )
        model = Beverage
