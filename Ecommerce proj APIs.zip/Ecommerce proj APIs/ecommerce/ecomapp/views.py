from django.shortcuts import render
from rest_framework import generics
from .serializers import CategorySerializer,DishSerializer,BeverageSerializer
from .models import Category,Dish,Beverage

# Create your views here.
class ListCategory(generics.ListCreateAPIView):
    queryset    =   Category.objects.all()
    serializer_class = CategorySerializer


class DetailCategory(generics.RetrieveUpdateDestroyAPIView):
    queryset    =   Category.objects.all()
    serializer_class = CategorySerializer
    
class ListDish(generics.ListCreateAPIView):
    queryset    =   Dish.objects.all()
    serializer_class = DishSerializer


class DetailDish(generics.RetrieveUpdateDestroyAPIView):
    queryset    =   Dish.objects.all()
    serializer_class = DishSerializer

class ListBeverage(generics.ListCreateAPIView):
    queryset    =   Beverage.objects.all()
    serializer_class = BeverageSerializer


class DetailBeverage(generics.RetrieveUpdateDestroyAPIView):
    queryset    =   Beverage.objects.all()
    serializer_class = BeverageSerializer
